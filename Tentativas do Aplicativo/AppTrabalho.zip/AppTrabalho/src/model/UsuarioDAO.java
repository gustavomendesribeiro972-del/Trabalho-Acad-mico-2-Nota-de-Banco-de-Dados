
package model;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import util.Conexao;


public class UsuarioDAO {
    
    public void cadastrar(Usuario usuario) throws SQLException {
        // 1. SQL com placeholders (?) para evitar erros de sintaxe
        String sql = "INSERT INTO usuario (nome, email, senha, usuario_tipo) VALUES (?, ?, ?, ?)";

        // 2. O try-with-resources abre e FECHA a conexão automaticamente
        try (Connection conn = new Conexao().conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getSenha());
            stmt.setInt(4, usuario.getUsuario_tipo());

            // 3. O comando que realmente salva os dados
            int linhas = stmt.executeUpdate(); 

            if (linhas > 0) {
                System.out.println("✅ Salvo no PostgreSQL com sucesso!");
            }
        } catch (SQLException e) {
            System.err.println("❌ Erro no banco: " + e.getMessage());
            throw e;
        }
    }
}
