
package model;

public class Arquivo {
    private int id_arquivo;
    private int usuario_uploader;
    private String nome;
    private int acesso;
    private String tipo;
    private String date;

    public Arquivo() {  
    }

    public Arquivo(int id_arquivo, int usuario_uploader, String nome, int acesso, String tipo, String date) {
        this.id_arquivo = id_arquivo;
        this.usuario_uploader = usuario_uploader;
        this.nome = nome;
        this.acesso = acesso;
        this.tipo = tipo;
        this.date = date;
    }

    public Arquivo(int usuario_uploader, String nome, int acesso, String tipo, String date) {
        this.usuario_uploader = usuario_uploader;
        this.nome = nome;
        this.acesso = acesso;
        this.tipo = tipo;
        this.date = date;
    }

    public int getId_arquivo() {
        return id_arquivo;
    }

    public void setId_arquivo(int id_arquivo) {
        this.id_arquivo = id_arquivo;
    }

    public int getUsuario_uploader() {
        return usuario_uploader;
    }

    public void setUsuario_uploader(int usuario_uploader) {
        this.usuario_uploader = usuario_uploader;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAcesso() {
        return acesso;
    }

    public void setAcesso(int acesso) {
        this.acesso = acesso;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }  
}
