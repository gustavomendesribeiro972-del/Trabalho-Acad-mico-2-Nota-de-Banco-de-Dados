package model;

//REGRAS DE NEGOCIO
import java.util.List;
import java.sql.SQLException;

public class UsuarioService {

    public void cadastrar(Usuario usuario) throws Exception {
        if (usuario.getNome() == null || usuario.getNome().isEmpty() || usuario.getEmail() == null || usuario.getEmail().isEmpty() || usuario.getSenha() == null || usuario.getSenha().isEmpty()) {
            throw new Exception("Todos os campos devem ser preenchidos. O novo Usuário nao ofereceu tudo.");
        }

        // Validação básica de E-mail (deve conter @ e um domínio)
        if (!usuario.getEmail().contains("@") || !usuario.getEmail().contains(".com")) {
            throw new Exception("E-mail inválido inserido.");
        }

        // Validação de Segurança da Senha (mínimo 6 caracteres)
        if (usuario.getSenha().length() < 8) {
            throw new Exception("A senha deve ter pelo menos 8 caracteres.");
        } else if (usuario.getSenha().length() > 16) {
            throw new Exception("A senha não pode ter mais que 16 caracteres.");
        }

        if (usuario.getUsuario_tipo() <= 0) {
            System.out.printf("%s é um administrador", usuario.getNome());
        } else if (usuario.getUsuario_tipo() != 0 && usuario.getUsuario_tipo() != 1) {
            throw new Exception("Tipo inválido de usuário");
        } else {
            System.out.println("Cadastrando na base de dados...");
            UsuarioDAO dao = new UsuarioDAO();
            try {
                dao.cadastrar(usuario);
            } catch (SQLException e) {
                System.out.println(e.getSQLState());
                throw new Exception("Erro ao inserir no SQL");
            }
        }
    }

    public List<Usuario> listar() {
        return null;
    }
}
