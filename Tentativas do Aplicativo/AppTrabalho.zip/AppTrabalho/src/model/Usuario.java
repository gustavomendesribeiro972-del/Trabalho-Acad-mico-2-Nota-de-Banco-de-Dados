
package model;

public class Usuario {
    private int id_usuario;
    private int usuario_tipo;
    private String nome;
    private String email;
    private String senha;

    public Usuario() {
    }

    public Usuario(int id_usuario, int usuario_tipo, String nome, String email, String senha) {
        this.id_usuario = id_usuario;
        this.usuario_tipo = usuario_tipo;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    public Usuario(String nome, String email, String senha) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }
    
    //getters e setters

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getUsuario_tipo() {
        return usuario_tipo;
    }

    public void setUsuario_tipo(int usuario_tipo) {
        this.usuario_tipo = usuario_tipo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    
}
