
package util;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class Conexao {
    private static String URL = "jdbc:postgresql://localhost:5432/FLASHArquival";
    private static String USUARIO = "postgres";
    private static String SENHA = "root";
    
    public Connection conectar() throws SQLException{
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }
}
