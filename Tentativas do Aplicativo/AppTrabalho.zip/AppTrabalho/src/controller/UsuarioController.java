
package controller;

import model.Usuario;
import model.UsuarioService;

public class UsuarioController {

    private UsuarioService usuarioservice;
    
    public UsuarioController() {
        usuarioservice = new UsuarioService();        
    }
    
    public void cadastrar(Usuario usuario) throws Exception{
        System.out.println("Chegou novo usuário");
        System.out.println("Camada Model Acionada...");
        System.out.println("Camada Model de Serviço Acionada...");
        
        usuarioservice.cadastrar(usuario);
    }
    
}
