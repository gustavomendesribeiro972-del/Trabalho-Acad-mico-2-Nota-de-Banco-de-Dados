
package controller;

import java.util.List;
import model.Arquivo;

public class ArquivoController {
    public void Exportar(Arquivo arquivo){
        
    }
    
    public void Atualizar(Arquivo arquivo){
        
    }
    
    public void excluir(int id_arquivo){
        
    }
    
    public List<Arquivo> listar(){
        return null;
    }
}
